<div id="city_chipin_widget-<?php echo $chipin_widget_id; ?>">Loading Widget</div>
<script type="text/javascript">
   load_info_for_widget('<?php echo $chipin_widget_id; ?>');
</script>
