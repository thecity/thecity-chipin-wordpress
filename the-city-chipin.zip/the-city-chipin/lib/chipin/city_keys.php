<?php

define("APIKEY","YOUR API KEY");
define("USERTOKEN", "YOUR API TOKEN"); 
$api_key = APIKEY;
$user_token = USERTOKEN;

?>